import style from "./Meowlien.module.css"

export function Meowlien() {
    return <img class={style.Meowlien} src="https://cdn.discordapp.com/emojis/1243983362813726892.webp?size=48" alt="meowlien"/>
}